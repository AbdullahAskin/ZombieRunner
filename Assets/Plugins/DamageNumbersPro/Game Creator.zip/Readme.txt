These files are for Game Creator users.

If you use [Game Creator 1] only extract the [Version 1] folder into the [Game Creator] folder.
If you use [Game Creator 2] only extract the [Version 2] folder into the [Damage Numbers Pro] folder.


Only extract the [GCX_DNP_Stats.cs] file if you use the Stats system.
That custom action (or instruction in GC2) will match your [Change Attribute] or [Change Stat] actions.

Look into the documentation for more information:
https://ekincantas.com/damage-numbers-pro/