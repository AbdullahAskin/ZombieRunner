﻿namespace GameCreator.Core
{
	using System.Collections;
	using System.Collections.Generic;
	using UnityEngine;
	using UnityEngine.Events;
	using DamageNumbersPro;
    using TMPro;

    #if UNITY_EDITOR
    using UnityEditor;
    #endif

    [AddComponentMenu("")]
	public class GC1_DNP_Basic : IAction
	{
        //Main:
		public DamageNumber prefab;

        //Position:
        public TargetGameObject target = new TargetGameObject(TargetGameObject.Target.Invoker);
        public bool useTargetChild = false;
        public string childName = "";
        public Vector3 relativeOffset = Vector3.zero;
        public bool hasRandomOffset = false;
        public Vector3 randomOffset = Vector3.zero;

        //Number:
        public bool hasNumber;
        public bool randomNumber;
        public float number = 1;
        public float fromNumber = 1;
        public float toNumber = 3;
        public bool roundNumber;
        public bool hideMinus;

        //Text:
        public bool modifyText = false;
        public bool hasLeftText;
        public string leftText;
        public bool hasRightText;
        public string rightText;
        public bool hasTopText;
        public string topText;
        public bool hasBottomText;
        public string bottomText;

        //Text Visuals:
        public bool changeFont;
        public TMP_FontAsset font;
        public bool changeColor;
        public Color color = Color.white;
        public bool randomColor;
        public Gradient colorGradient;
        public bool vertexColor;
        public VertexGradient vertexGradient = new VertexGradient(Color.white, new Color(0.8f,0.8f,0.8f,1), Color.gray, Color.black);

        //Utiltiy:
        public bool followTarget;
        public bool isGUI;
        public Vector2 anchoredPosition;

        public override bool InstantExecute(GameObject target, IAction[] actions, int index)
        {
            if(prefab != null)
            {
                //Get Transform:
                Transform positionTarget = this.target.GetGameObject(target).transform;
                if (useTargetChild)
                {
                    Transform positionChild = positionTarget.Find(childName);
                    if(positionChild != null)
                    {
                        positionTarget = positionChild;
                    }
                }

                //Position:
                Vector3 position = positionTarget.position + relativeOffset;
                if(hasRandomOffset)
                {
                    position.x += (Random.value * 2 - 1) * randomOffset.x;
                    position.y += (Random.value * 2 - 1) * randomOffset.y;
                    position.z += (Random.value * 2 - 1) * randomOffset.z;
                }

                //Spawn:
                DamageNumber newPopup = prefab.Spawn(position);

                //Number:
                if(hasNumber)
                {
                    newPopup.enableNumber = true;

                    newPopup.number = randomNumber ? Random.Range(fromNumber, toNumber) : number;
                    if (hideMinus)
                    {
                        newPopup.number = Mathf.Abs(newPopup.number);
                    }
                    if (roundNumber)
                    {
                        newPopup.number = Mathf.Round(newPopup.number);
                    }
                }
                else
                {
                    newPopup.enableNumber = false;
                }

                //Text:
                if(modifyText)
                {
                    newPopup.enableLeftText = hasLeftText;
                    if(hasLeftText)
                    {
                        newPopup.leftText = leftText;
                    }

                    newPopup.enableRightText = hasRightText;
                    if (hasRightText)
                    {
                        newPopup.rightText = rightText;
                    }

                    newPopup.enableTopText = hasTopText;
                    if (hasTopText)
                    {
                        newPopup.topText = topText;
                    }

                    newPopup.enableBottomText = hasBottomText;
                    if (hasBottomText)
                    {
                        newPopup.bottomText = bottomText;
                    }
                }

                //Font:
                if(changeFont)
                {
                    newPopup.SetFontMaterial(font);
                }

                //Color:
                if (changeColor)
                {
                    newPopup.SetColor(color);
                }

                //Random Color:
                if(randomColor)
                {
                    newPopup.SetRandomColor(colorGradient);
                }

                //Vertex Color:
                if(vertexColor)
                {
                    newPopup.SetGradientColor(vertexGradient);
                }
                
                //Follow:
                if(followTarget && positionTarget != null)
                {
                    newPopup.SetFollowedTarget(positionTarget);
                }

                //GUI:
                if(isGUI)
                {
                    newPopup.SetAnchoredPosition(positionTarget, anchoredPosition);
                }
            }
            else
            {
                Debug.Log("Damage number prefab is missing.", target);
            }
            return true;
        }

		#if UNITY_EDITOR
        public static new string NAME = "Damage Numbers Pro/Basic Popup";

        public override string GetNodeTitle()
        {
			string popupTitle = "Popup";

			if(prefab == null)
            {
				popupTitle += " (prefab missing)";
            }else
            {
				popupTitle = (hasNumber ? "Number " : "Text ") + popupTitle;
            }

			return popupTitle;
        }

        public override void OnInspectorGUI()
        {
            //Start:
            serializedObject.Update();
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.BeginVertical();
            GUIStyle labelStyle = new GUIStyle(GUI.skin.label);
            labelStyle.richText = true;

            //Prefab:
            EditorGUILayout.LabelField("<b><size=14>Main:</size></b>", labelStyle);
            EditorGUI.BeginChangeCheck();
            EditorGUILayout.PropertyField(serializedObject.FindProperty("prefab"));
            if (EditorGUI.EndChangeCheck())
            {
                Object newPrefab = serializedObject.FindProperty("prefab").objectReferenceValue;
                if(newPrefab != null && newPrefab.GetType().IsSubclassOf(typeof(DamageNumber)))
                {
                    DamageNumber newDNP = ((DamageNumber)newPrefab);
                    serializedObject.FindProperty("hasNumber").boolValue = newDNP.enableNumber;
                }
            }
            if (prefab == null)
            {
                GUI.color = new Color(1, 1, 1, 0.7f);
                EditorGUILayout.LabelField("- First <b>drag</b> your damage number's <b>prefab</b> into this field.", labelStyle);
                GUI.color = Color.white;
            }
            GUI.enabled = prefab != null;
            Lines();

            //Target & Position:
            EditorGUILayout.LabelField("<b><size=14>Position:</size></b>", labelStyle);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("target"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("useTargetChild"));
            if (useTargetChild)
            {
                BeginSubgroup(labelStyle);
                EditorGUILayout.PropertyField(serializedObject.FindProperty("childName"));
                EndSubgroup();
            }
            EditorGUILayout.PropertyField(serializedObject.FindProperty("relativeOffset"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("hasRandomOffset"));
            if (hasRandomOffset)
            {
                BeginSubgroup(labelStyle);
                EditorGUILayout.PropertyField(serializedObject.FindProperty("randomOffset"));
                EndSubgroup();
            }
            Lines();

            //Number:
            EditorGUILayout.LabelField("<b><size=14>Number:</size></b>", labelStyle);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("hasNumber"));
            if(hasNumber)
            {
                BeginSubgroup(labelStyle, "<size=14><b>↘</b></size>");
                EditorGUILayout.PropertyField(serializedObject.FindProperty("randomNumber"));
                if (randomNumber)
                {
                    EditorGUILayout.PropertyField(serializedObject.FindProperty("fromNumber"));
                    EditorGUILayout.PropertyField(serializedObject.FindProperty("toNumber"));
                }
                else
                {
                    EditorGUILayout.PropertyField(serializedObject.FindProperty("number"));
                }
                EditorGUILayout.PropertyField(serializedObject.FindProperty("roundNumber"));
                EditorGUILayout.PropertyField(serializedObject.FindProperty("hideMinus"));
                EndSubgroup();
            }
            Lines();

            //Text:
            EditorGUILayout.LabelField("<b><size=14>Text:</size></b>", labelStyle);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("modifyText"));
            if(modifyText)
            {
                BeginSubgroup(labelStyle, "<size=14><b>↘</b></size>");
                EditorGUILayout.PropertyField(serializedObject.FindProperty("hasLeftText"));
                if(hasLeftText)
                {
                    BeginSubgroup(labelStyle);
                    EditorGUILayout.PropertyField(serializedObject.FindProperty("leftText"));
                    EndSubgroup();
                }

                EditorGUILayout.PropertyField(serializedObject.FindProperty("hasRightText"));
                if (hasRightText)
                {
                    BeginSubgroup(labelStyle);
                    EditorGUILayout.PropertyField(serializedObject.FindProperty("rightText"));
                    EndSubgroup();
                }

                EditorGUILayout.PropertyField(serializedObject.FindProperty("hasTopText"));
                if (hasTopText)
                {
                    BeginSubgroup(labelStyle);
                    EditorGUILayout.PropertyField(serializedObject.FindProperty("topText"));
                    EndSubgroup();
                }

                EditorGUILayout.PropertyField(serializedObject.FindProperty("hasBottomText"));
                if (hasBottomText)
                {
                    BeginSubgroup(labelStyle);
                    EditorGUILayout.PropertyField(serializedObject.FindProperty("bottomText"));
                    EndSubgroup();
                }
                EndSubgroup();
            }

            Lines();
            EditorGUILayout.LabelField("<b><size=14>Style:</size></b>", labelStyle);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("changeFont"));
            if(changeFont)
            {
                BeginSubgroup(labelStyle);
                EditorGUILayout.PropertyField(serializedObject.FindProperty("font"));
                EndSubgroup();
            }
            EditorGUILayout.PropertyField(serializedObject.FindProperty("changeColor"));
            if (changeColor)
            {
                BeginSubgroup(labelStyle);
                EditorGUILayout.PropertyField(serializedObject.FindProperty("color"));
                EndSubgroup();
            }
            EditorGUILayout.PropertyField(serializedObject.FindProperty("randomColor"));
            if (randomColor)
            {
                BeginSubgroup(labelStyle);
                EditorGUILayout.PropertyField(serializedObject.FindProperty("colorGradient"));
                EndSubgroup();
            }
            EditorGUILayout.PropertyField(serializedObject.FindProperty("vertexColor"));
            if (vertexColor)
            {
                BeginSubgroup(labelStyle, " ");
                EditorGUILayout.PropertyField(serializedObject.FindProperty("vertexGradient"));
                EndSubgroup();
            }

            Lines();
            EditorGUILayout.LabelField("<b><size=14>Utility:</size></b>", labelStyle);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("followTarget"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("isGUI"));
            if(isGUI)
            {
                BeginSubgroup(labelStyle);
                EditorGUILayout.PropertyField(serializedObject.FindProperty("anchoredPosition"));
                EndSubgroup();
            }


            //Finish:
            GUI.enabled = true;
            EditorGUILayout.EndVertical();
            GUILayout.Label(" ", GUILayout.Width(2));
            EditorGUILayout.EndHorizontal();
            serializedObject.ApplyModifiedProperties();
        }

        private static void Lines()
        {
            GUI.color = new Color(1, 1, 1, 0.7f);
            EditorGUILayout.LabelField(" - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
            GUI.color = Color.white;
        }

        private static void BeginSubgroup(GUIStyle labelStyle, string content = "<size=14><b>↪</b></size>")
        {
            EditorGUILayout.BeginHorizontal();
            GUI.color = new Color(1, 1, 1, 0.7f);
            GUILayout.Label(content, labelStyle, GUILayout.Width(19));
            GUI.color = Color.white;
            EditorGUILayout.BeginVertical();
        }

        private static void EndSubgroup()
        {
            EditorGUILayout.EndVertical();
            EditorGUILayout.EndHorizontal();
        }
        #endif
    }
}
