﻿namespace GameCreator.Core
{
	using System.Collections;
	using System.Collections.Generic;
	using UnityEngine;
	using UnityEngine.Events;
	using DamageNumbersPro;
    using TMPro;
    using GameCreator.Stats;

    #if UNITY_EDITOR
    using UnityEditor;
    #endif

    [AddComponentMenu("")]
	public class GC1_DNP_Stats : IAction
	{
        //Main:
		public DamageNumber prefab;

        //Position:
        public TargetGameObject target = new TargetGameObject(TargetGameObject.Target.Invoker);
        public bool useTargetChild = false;
        public string childName = "";
        public Vector3 relativeOffset = Vector3.zero;
        public bool hasRandomOffset = false;
        public Vector3 randomOffset = Vector3.zero;

        //Number:
        public bool roundNumber;
        public bool hideMinus;
        public bool multiplyNumber;
        public float multiplyFactor = 1f;

        //Text:
        public bool modifyText = false;
        public bool hasLeftText;
        public string leftText;
        public bool hasRightText;
        public string rightText;
        public bool hasTopText;
        public string topText;
        public bool hasBottomText;
        public string bottomText;

        //Text Visuals:
        public bool changeFont;
        public TMP_FontAsset font;
        public bool changeColor;
        public Color color = Color.white;
        public bool randomColor;
        public Gradient colorGradient;
        public bool vertexColor;
        public VertexGradient vertexGradient = new VertexGradient(Color.white, new Color(0.8f,0.8f,0.8f,1), Color.gray, Color.black);

        //Utiltiy:
        public bool followTarget;
        public bool isGUI;
        public Vector2 anchoredPosition;

        private ActionChangeAttribute attributeAction;
        private ActionChangeStat statAction;

        public override bool InstantExecute(GameObject target, IAction[] actions, int index)
        {
            if(prefab != null)
            {
                //Get Transform:
                Transform positionTarget = this.target.GetGameObject(target).transform;
                if (useTargetChild)
                {
                    Transform positionChild = positionTarget.Find(childName);
                    if(positionChild != null)
                    {
                        positionTarget = positionChild;
                    }
                }

                //Position:
                Vector3 position = positionTarget.position + relativeOffset;
                if(hasRandomOffset)
                {
                    position.x += (Random.value * 2 - 1) * randomOffset.x;
                    position.y += (Random.value * 2 - 1) * randomOffset.y;
                    position.z += (Random.value * 2 - 1) * randomOffset.z;
                }

                //Spawn:
                DamageNumber newPopup = prefab.Spawn(position);

                //Number:
                newPopup.enableNumber = true;

                //Find Attribute:
                if(attributeAction == null && statAction == null)
                {
                    for(int i = 0; i < actions.Length; i++)
                    {
                        System.Type type = actions[i].GetType();

                        if (type == typeof(ActionChangeAttribute))
                        {
                            attributeAction = (ActionChangeAttribute)actions[i];
                            if (i == index - 1 || i == index + 1)
                            {
                                break;
                            }
                        }
                        else if (type == typeof(ActionChangeStat))
                        {
                            statAction = (ActionChangeStat) actions[i];
                            if (i == index - 1 || i == index + 1)
                            {
                                break;
                            }
                        }
                    }
                }

                //Calculate Number:
                if (attributeAction != null)
                {
                    Stats componentTarget = attributeAction.target.GetGameObject(target).GetComponentInChildren<Stats>();
                    if (componentTarget != null)
                    {
                        float value = 0.0f;
                        switch (attributeAction.valueType)
                        {
                            case ActionChangeAttribute.ValueType.Value:
                                value = attributeAction.amount.GetValue(target);
                                break;

                            case ActionChangeAttribute.ValueType.Formula:
                                Stats componentOther = attributeAction.opponent.GetGameObject(target).GetComponentInChildren<Stats>();
                                value = attributeAction.formula.formula.Calculate(0.0f, componentTarget, componentOther);
                                break;
                        }

                        newPopup.number = value;
                    }
                }
                else if (statAction != null)
                {
                    Stats componentTarget = statAction.target.GetGameObject(target).GetComponentInChildren<Stats>();
                    if (componentTarget != null)
                    {
                        float value = 0.0f;
                        switch (statAction.valueType)
                        {
                            case ActionChangeStat.ValueType.Value:
                                value = statAction.amount.GetValue(target);
                                break;
                            case ActionChangeStat.ValueType.Formula:
                                Stats componentOther = statAction.opponent.GetGameObject(target).GetComponentInChildren<Stats>();
                                value = statAction.formula.formula.Calculate(0.0f, componentTarget, componentOther);
                                break;
                        }

                        newPopup.number = value;
                    }
                }
                else
                {
                    Debug.Log("This action has to be in the same actions collection as a Stats Change Attribute action.");
                }

                if(multiplyNumber)
                {
                    newPopup.number *= multiplyFactor;
                }
                if (hideMinus)
                {
                    newPopup.number = Mathf.Abs(newPopup.number);
                }
                if (roundNumber)
                {
                    newPopup.number = Mathf.Round(newPopup.number);
                }

                //Text:
                if (modifyText)
                {
                    newPopup.enableLeftText = hasLeftText;
                    if(hasLeftText)
                    {
                        newPopup.leftText = leftText;
                    }

                    newPopup.enableRightText = hasRightText;
                    if (hasRightText)
                    {
                        newPopup.rightText = rightText;
                    }

                    newPopup.enableTopText = hasTopText;
                    if (hasTopText)
                    {
                        newPopup.topText = topText;
                    }

                    newPopup.enableBottomText = hasBottomText;
                    if (hasBottomText)
                    {
                        newPopup.bottomText = bottomText;
                    }
                }

                //Font:
                if(changeFont)
                {
                    newPopup.SetFontMaterial(font);
                }

                //Color:
                if (changeColor)
                {
                    newPopup.SetColor(color);
                }

                //Random Color:
                if(randomColor)
                {
                    newPopup.SetRandomColor(colorGradient);
                }

                //Vertex Color:
                if(vertexColor)
                {
                    newPopup.SetGradientColor(vertexGradient);
                }
                
                //Follow:
                if(followTarget && positionTarget != null)
                {
                    newPopup.SetFollowedTarget(positionTarget);
                }

                //GUI:
                if(isGUI)
                {
                    newPopup.SetAnchoredPosition(positionTarget, anchoredPosition);
                }
            }
            else
            {
                Debug.Log("Damage number prefab is missing.", target);
            }
            return true;
        }

		#if UNITY_EDITOR
        public static new string NAME = "Damage Numbers Pro/Stats Popup";

        public override string GetNodeTitle()
        {
			string popupTitle = "Stats Popup";

			if(prefab == null)
            {
				popupTitle += " (prefab missing)";
            }else
            {
				//Check Stats
            }

			return popupTitle;
        }

        public override void OnInspectorGUI()
        {
            //Start:
            serializedObject.Update();
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.BeginVertical();
            GUIStyle labelStyle = new GUIStyle(GUI.skin.label);
            labelStyle.richText = true;

            //Information:
            EditorGUILayout.LabelField("<b><size=14>Important:</size></b>", labelStyle);
            EditorGUILayout.LabelField("This has to be in a collection of actions with a <b>Change Stat</b> or <b>Change Attribute</b> action.", labelStyle);
            EditorGUILayout.LabelField("If you are not using the <b>Stats</b> system, please use the <b>Basic Popup</b> action.", labelStyle);
            Lines();

            //Prefab:
            EditorGUILayout.LabelField("<b><size=14>Main:</size></b>", labelStyle);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("prefab"));
            if (prefab == null)
            {
                GUI.color = new Color(1, 1, 1, 0.7f);
                EditorGUILayout.LabelField("- First <b>drag</b> your damage number's <b>prefab</b> into this field.", labelStyle);
                GUI.color = Color.white;
            }
            GUI.enabled = prefab != null;
            Lines();

            //Target & Position:
            EditorGUILayout.LabelField("<b><size=14>Position:</size></b>", labelStyle);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("target"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("useTargetChild"));
            if (useTargetChild)
            {
                BeginSubgroup(labelStyle);
                EditorGUILayout.PropertyField(serializedObject.FindProperty("childName"));
                EndSubgroup();
            }
            EditorGUILayout.PropertyField(serializedObject.FindProperty("relativeOffset"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("hasRandomOffset"));
            if (hasRandomOffset)
            {
                BeginSubgroup(labelStyle);
                EditorGUILayout.PropertyField(serializedObject.FindProperty("randomOffset"));
                EndSubgroup();
            }
            Lines();

            //Number:
            EditorGUILayout.LabelField("<b><size=14>Number:</size></b>", labelStyle);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("roundNumber"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("hideMinus"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("multiplyNumber"));
            if(multiplyNumber)
            {
                BeginSubgroup(labelStyle);
                EditorGUILayout.PropertyField(serializedObject.FindProperty("multiplyFactor"));
                EndSubgroup();
            }
            GUI.color = new Color(1, 1, 1, 0.7f);
            EditorGUILayout.LabelField("- Value is taken from a <b>Change Attribute</b> or <b>Change Stat</b> action within this collection.", labelStyle);
            EditorGUILayout.LabelField("- Neighbouring <b>Stats Actions</b> are prioritized.", labelStyle);
            Lines();

            //Text:
            EditorGUILayout.LabelField("<b><size=14>Text:</size></b>", labelStyle);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("modifyText"));
            if(modifyText)
            {
                BeginSubgroup(labelStyle, "<size=14><b>↘</b></size>");
                EditorGUILayout.PropertyField(serializedObject.FindProperty("hasLeftText"));
                if(hasLeftText)
                {
                    BeginSubgroup(labelStyle);
                    EditorGUILayout.PropertyField(serializedObject.FindProperty("leftText"));
                    EndSubgroup();
                }

                EditorGUILayout.PropertyField(serializedObject.FindProperty("hasRightText"));
                if (hasRightText)
                {
                    BeginSubgroup(labelStyle);
                    EditorGUILayout.PropertyField(serializedObject.FindProperty("rightText"));
                    EndSubgroup();
                }

                EditorGUILayout.PropertyField(serializedObject.FindProperty("hasTopText"));
                if (hasTopText)
                {
                    BeginSubgroup(labelStyle);
                    EditorGUILayout.PropertyField(serializedObject.FindProperty("topText"));
                    EndSubgroup();
                }

                EditorGUILayout.PropertyField(serializedObject.FindProperty("hasBottomText"));
                if (hasBottomText)
                {
                    BeginSubgroup(labelStyle);
                    EditorGUILayout.PropertyField(serializedObject.FindProperty("bottomText"));
                    EndSubgroup();
                }
                EndSubgroup();
            }

            Lines();
            EditorGUILayout.LabelField("<b><size=14>Style:</size></b>", labelStyle);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("changeFont"));
            if(changeFont)
            {
                BeginSubgroup(labelStyle);
                EditorGUILayout.PropertyField(serializedObject.FindProperty("font"));
                EndSubgroup();
            }
            EditorGUILayout.PropertyField(serializedObject.FindProperty("changeColor"));
            if (changeColor)
            {
                BeginSubgroup(labelStyle);
                EditorGUILayout.PropertyField(serializedObject.FindProperty("color"));
                EndSubgroup();
            }
            EditorGUILayout.PropertyField(serializedObject.FindProperty("randomColor"));
            if (randomColor)
            {
                BeginSubgroup(labelStyle);
                EditorGUILayout.PropertyField(serializedObject.FindProperty("colorGradient"));
                EndSubgroup();
            }
            EditorGUILayout.PropertyField(serializedObject.FindProperty("vertexColor"));
            if (vertexColor)
            {
                BeginSubgroup(labelStyle, " ");
                EditorGUILayout.PropertyField(serializedObject.FindProperty("vertexGradient"));
                EndSubgroup();
            }

            Lines();
            EditorGUILayout.LabelField("<b><size=14>Utility:</size></b>", labelStyle);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("followTarget"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("isGUI"));
            if(isGUI)
            {
                BeginSubgroup(labelStyle);
                EditorGUILayout.PropertyField(serializedObject.FindProperty("anchoredPosition"));
                EndSubgroup();
            }

            //Finish:
            GUI.enabled = true;
            EditorGUILayout.EndVertical();
            GUILayout.Label(" ", GUILayout.Width(2));
            EditorGUILayout.EndHorizontal();
            serializedObject.ApplyModifiedProperties();
        }

        private static void Lines()
        {
            GUI.color = new Color(1, 1, 1, 0.7f);
            EditorGUILayout.LabelField(" - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
            GUI.color = Color.white;
        }

        private static void BeginSubgroup(GUIStyle labelStyle, string content = "<size=14><b>↪</b></size>")
        {
            EditorGUILayout.BeginHorizontal();
            GUI.color = new Color(1, 1, 1, 0.7f);
            GUILayout.Label(content, labelStyle, GUILayout.Width(19));
            GUI.color = Color.white;
            EditorGUILayout.BeginVertical();
        }

        private static void EndSubgroup()
        {
            EditorGUILayout.EndVertical();
            EditorGUILayout.EndHorizontal();
        }
        #endif
    }
}
